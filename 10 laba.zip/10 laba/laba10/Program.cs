﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace laba10
{
    class Student
    {
        public string Name { get; set; }
        public int Years { get; set; }
        public Student(string name, int years)
        {
            this.Name = name;
            this.Years = years;
        }


    }
    public class Bench : IComparable<Bench>  //скамейка
    {
        public string Name { get; set; }
        public string Material { get; set; }
        private int cost { get; set; }
        public int Cost
        {
            get { return cost; }
            set
            {
                cost = value;
            }
        }

        public Bench()
        {
            Name = "Bench";
            Material = "Tree";
            Cost = 1000;
        }

        public Bench(string name, string material, int cost)
        {
            Name = name;
            Material = material;
            Cost = cost;
        }

        public override string ToString()
        {
            return ($"Name: {Name} \nMaterial: {Material} \nCost: {Cost}");
        }
        public int CompareTo(Bench bench)
        {
            return this.Cost.CompareTo(bench.Cost);
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--------ArrayList--------");
            ArrayList array = new ArrayList(); //ArrayList
            Random random = new Random();
            for (int i = 0; i < 5; i++)  //заполнить 5-ю случайными числами
            {
                array.Add(Convert.ToString(random.Next(0, 100)));
            }
            string str = "Добавленная строка.";  //добавить строку
            array.Add(str);
            Student student = new Student("Aleksandra", 19);
            array.Add(student.Name + " " + student.Years);  //объект типа Student
            void InfoArray()  //вывод коллекции
            {
                foreach (var element in array)
                {
                    Console.WriteLine(element);
                }
            }
            InfoArray();
            Console.WriteLine($"\nКоличество элементов: {array.Count}");  //количество
            Console.WriteLine();
            Console.WriteLine("Введите элемент, который требуется удалить:");
            array.Remove(Console.ReadLine());   //удаление элемента
            Console.WriteLine();
            Console.WriteLine("ArrayList после удаления элемента: ");
            InfoArray();
            Console.WriteLine($"\nКоличество элементов после удаления одного из них: {array.Count}");
            Console.WriteLine("\nВведите элемент, который требуется найти:"); //поиск значения
            if (array.Contains(Console.ReadLine()))
            {
                Console.WriteLine("\nЭлемент в коллекции найден.");
            }
            else
            {
                Console.WriteLine("\nЭлемента в коллекции нет.");
            }
            //////////////////////////////////////////////
            Console.WriteLine("\n--------Stack<T>--------");  //LIFO
            Stack<double> stack = new Stack<double>();
            stack.Push(0.221);
            stack.Push(6.28);
            stack.Push(28.44);
            stack.Push(3.255);
            stack.Push(21.99);
            stack.Push(4.48);
            void InfoStack()  //вывод коллекции
            {
                foreach (double element in stack)
                {
                    Console.WriteLine(element);
                }
            }
            InfoStack();
            Console.WriteLine("\nВведите количество элементов, которое требуется удалить:"); //удаление элементов
            int n = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                stack.Pop();
            }
            InfoStack();

            Console.WriteLine("\n--------LinkedList<T>--------");
            LinkedList<double> list = new LinkedList<double>();
            for (; stack.Count != 0;)  //заполнение коллекции данными из первой коллекции
            {
                list.AddLast(stack.Pop());
            }
            foreach (double element in list)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("\nВведите элемент, который требуется найти:"); //поиск значения

            if (list.Contains(Convert.ToDouble(Console.ReadLine())))
            {
                Console.WriteLine("\nЭлемент в коллекции найден.");
            }
            else
            {
                Console.WriteLine("\nЭлемента в коллекции нет.");

            }
            /////////////////////////////
            Console.WriteLine("\n--------Коллекция Stack с пользовательским типом данных--------");
            Stack<Bench> stackBench = new Stack<Bench>();
            Bench bench1 = new Bench("bench1", "дерево", 1500);
            Bench bench2 = new Bench("bench2", "дерево", 1200);
            Bench bench3 = new Bench("bench3", "дерево", 1400);
            Bench bench4 = new Bench("bench4", "дерево", 1300);
            stackBench.Push(bench1);   //заполнение коллекции
            stackBench.Push(bench2);
            stackBench.Push(bench3);
            stackBench.Push(bench4);
            foreach (Bench bench in stackBench)
            {
                Console.WriteLine(bench + "\n");
            }
            Console.WriteLine("\n--------Коллекция LinkedLIst с пользовательским типом данных--------");
            LinkedList<Bench> listBench = new LinkedList<Bench>();
            for (; stackBench.Count != 0;)
            {
                listBench.AddLast(stackBench.Pop());
            }
            foreach (Bench bench in listBench)
            {
                Console.WriteLine(bench + "\n");
            }
            ////////////////////////////////////////////
            Console.WriteLine("\n--------ObservableCollection<T>--------");
            ObservableCollection<Bench> obsCol = new ObservableCollection<Bench>();
            obsCol.CollectionChanged += ObsCol_CollectionChanged;
            obsCol.Add(bench1);
            obsCol.Add(bench2);
            obsCol.Add(bench3);
            obsCol.Add(bench4);
            obsCol.RemoveAt(1);
            Console.WriteLine("Коллекция после удаления элемента:");
            foreach (Bench bench in obsCol)
            {
                Console.WriteLine(bench.Name);
            }
            HashSet<int> q = new HashSet<int>();
           
            
        }

        private static void ObsCol_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            //свойство Action позволяет узнать характер изменений
            if (e.Action == NotifyCollectionChangedAction.Add)
            {
                Bench newBench = e.NewItems[0] as Bench; //Свойства NewItems и OldItems позволяют получить соответственно добавленные и удаленные объекты.
                Console.WriteLine($"Добавлен новый объект: {newBench.Name}");

            }

            else if (e.Action == NotifyCollectionChangedAction.Remove)
            {
                Bench oldBench = e.OldItems[0] as Bench;
                Console.WriteLine($"\nУдален объект: {oldBench.Name}");
            }

            else
            {
                Console.WriteLine("Нет изменений");
            }
        }
    }
}



