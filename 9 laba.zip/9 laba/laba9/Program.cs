﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba9
{
    public delegate void DelegateForUpgarde(int version); //делегаты
    public delegate void DelegateForWork(bool isOn);
    public class User
    {

        public string Name;

        public User(string name)
        {
            Name = name;
        }

        public event DelegateForUpgarde Upgrade;//события
        public event DelegateForWork Work;

        public void CommandForUpgrade(int version) //до какой версии обновить
        {
            Console.WriteLine("---обновление---");
            Upgrade?.Invoke(version);    //проверка на null при вызове делегата; ?-оператора условного null
        }

        public void CommandForWork(bool is_on) //компьютер работает/не работает
        {
            Work?.Invoke(is_on);
        }
    }
    public class PO
    {
        public int ID;
        public int Version;
        public bool IsOn;

        public PO(int version, int id)
        {
            Version = version;
            ID = id;
        }

        public void OnUpgrade(int version) //используется в качестве обработчика события
        {
            Version = version;
            PrintVersion();    //выводит информацию о версии компьютера
           
        }
        public void OnWork(bool isSwitchedOn) //используется в качестве обработчика события
        {
            IsOn = isSwitchedOn;
            PrintIsSwitchedOrNot();  //выводит информацию о том, включен или выключен компьютер
            
        }
        public void PrintVersion()
        {
            Console.WriteLine($"Версия ПО компьютера № {ID} : {Version}.");
        }
        public void PrintIsSwitchedOrNot()
        {
            if (IsOn==true) 
            {
                Console.WriteLine($"Компьютер № {ID} включен.");
            }
            else
            {
                Console.WriteLine($"Компьютер № {ID} выключен.");
            }
        }
    }
    public static class Operations
    {
        public static string DeletePunctuation(string str)
        {
            Console.WriteLine("\nСтрока после удаления пунктуации: ");
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if (!char.IsPunctuation(c))
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }
        public static void DeleteSpaces(string str, Action<string> method) 
        {
            string newStr;
            newStr = str.Replace(" ", "");
            method(newStr.ToString());

        }
        public static void ToUpperCase(string str, Action<string> method)
        {
           
            string newStr;
            newStr = str.ToUpper();
            method(newStr.ToString());

        }

        public static string ToLowerCase(string str)
        {
            Console.WriteLine("\nСтрока после замены на строчные: ");
            return str.ToLower();
        }
        
        public static string ToAddSymbols(string str)
        {
            Console.WriteLine("\nСтрока с новыми символами: ");
            return str+=" new symbols";
        }
        public static void InfoForUpperCase(string info)
        {
            Console.WriteLine($"\nСтрока после замены на заглавные: {info}");
        }
        public static void InfoForDeleteSpaces(string info)
        {
            Console.WriteLine($"\nСтрока после удаления пробелов: {info}");
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            User user1 = new User("Sasha");
            PO po1 = new PO(8, 1);
            po1.PrintVersion();
            user1.Upgrade += po1.OnUpgrade; //обработчик события
            user1.CommandForUpgrade(10);
            user1.Work += po1.OnWork;
            user1.CommandForWork(true);
            user1.CommandForWork(false);
            Console.WriteLine();
            User user2 = new User("Masha");
            PO po2 = new PO(11, 2);
            po2.PrintVersion();
            user2.Upgrade += po2.OnUpgrade;
            user2.CommandForUpgrade(12);
            user2.Work += po2.OnWork;
            user2.CommandForWork(true);
            //Func
            string str = "a! B& c? D E! f G h";
            Console.WriteLine($"\nИсходная строка:\n{str}");
            Func<string, string> strForOperations;
            strForOperations = Operations.ToLowerCase;
            Console.WriteLine(strForOperations(str));
            strForOperations = Operations.DeletePunctuation;
            Console.WriteLine(strForOperations(str));
            strForOperations = Operations.ToAddSymbols;
            Console.WriteLine(strForOperations(str));
            //Action
            Operations.ToUpperCase(str, Operations.InfoForUpperCase);
            Operations.DeleteSpaces(str, Operations.InfoForDeleteSpaces);


        }
    }
}
