﻿using System;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            static void the_first_a()
            {
                Console.WriteLine("1. Типы\nа) Примитивные типы");
                Console.WriteLine("bool: true or false\nbyte: целое число от 0 до 255 (1 байт)\nsbyte: целое число от -32768 до 32767 (1 байт)\n" +
                    "short: целое число от -32768 до 32767 (2 байта)\nushort: целое число от 0 до 65535 (2 байта)\nint: целое число от -2147483648 до 2147483647 (4 байта)" +
                    "\nuint: целое число от 0 до 4294967295 (4 байта)\nlong: целое число от –9 223 372 036 854 775 808 до 9 223 372 036 854 775 807 (8 байт)\nulong: целое число от 0 до 18 446 744 073 709 551 615 (8 байт)" +
                    "\nfloat: число с плавающей точкой от -3.4*10^38 до 3.4*10^38 (4 байта) \ndouble: число с плавающей точкой от ±5.0*10^(-324) до ±1.7*10^308 (8 байт)\ndecimal: значение от ±1.0*10^(-28) до ±7.9228*10^28 (16 байт)" +
                    "\nchar\nstring\nobject: может хранить значение любого типа данных");
                int ex = 100;
                Console.WriteLine($"int a={ex}");
            }
            the_first_a();
            static void the_first_b()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("б) Явное и неявное приведение");
                Console.WriteLine("НЕЯВНОЕ");
                int a = 5;
                float b = a;
                Console.WriteLine($"1.{b} ");
                int g = 2;
                int h = g;
                Console.WriteLine($"2.{h} ");
                float i = 1;
                float j = i;
                Console.WriteLine($"3.{j} ");
                float k = 5;
                double l = k;
                Console.WriteLine($"4.{l} ");
                double m = 1.5;
                double n = m;
                Console.WriteLine($"5.{n} ");
                Console.WriteLine("ЯВНОЕ");
                float c = 6;
                int d = (int)c;
                Console.WriteLine($"1.{d} ");
                double o = 1.5;
                int p = (int)o;
                Console.WriteLine($"2.{p} ");
                double e = 5.2;
                float f = (float)e;
                Console.WriteLine($"3.{f} ");
                int q = 31;
                byte r = (byte)q;
                Console.WriteLine($"4.{r}");
                double s = 389.89;
                short t = (short)s;
                Console.WriteLine($"5.{t} ");
            }
            the_first_b();
            static void the_first_c()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("в) Упаковка и распаковка значимых типов");
                int A = 1;
                object B = A;
                int C = (int)B;
                Console.WriteLine(C);
            }
            the_first_c();
            static void the_first_d()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("г) Неявно типизированная переменная");
                var hello = "Hello";
                var ch = 19;
                Console.WriteLine($"{hello}, {ch}");
            }
            the_first_d();
            static void the_first_e()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("д) Nullable переменная");
                int? x = null;
                if (x.HasValue)
                    Console.WriteLine(x.Value);
                else
                    Console.WriteLine("x is equal to null");

                Nullable<int> y = 9;
                if (y.HasValue)
                    Console.WriteLine(y.Value);
                else
                    Console.WriteLine("y is equal to null");
            }
            the_first_e();
            static void the_second_a()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("2. Строки\nа) Сравнение строковых литералов");
                string one = "Hello";
                string two = "hello";
                Console.WriteLine(one + " " + two);
                Console.WriteLine(one==two);
                Console.WriteLine(one.Equals(two));

                
            }
            the_second_a();

            static void the_second_b()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("б) Действия с тремя строками");
                string first = "First";
                string second = "Second";
                string third = "Third";
                Console.WriteLine($"{first} {second} {third}");
                string concat = String.Concat(first, second, third);
                Console.WriteLine("Сцепление: " + concat);

                string neww = String.Copy(second);
                Console.WriteLine("Копирование: " + neww);

                string text = "Microsoft Visual Studio";
                Console.WriteLine("Разделение:");
                string[] words = text.Split(new char[] { ' ' });
                foreach (string S in words)
                {
                    Console.WriteLine(S);
                }

                // индекс последнего символа
                int ind = text.Length - 3;
                // вырезаем последний символ
                text = text.Remove(ind);
                // вырезаем первые два символа
                text = text.Remove(0, 2);
                Console.WriteLine("Удаление подстроки: " + text);

                string textt = "Microsoft Visual Studio";
                string subString = " for C#";
                textt = textt.Insert(23, subString);
                Console.WriteLine("Вставка подстроки: " + textt);

                textt = textt.Substring(4, 5);
                Console.WriteLine("Выделение подстроки: " + textt);
            }
            the_second_b();
            static void the_second_с()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("в) Пустая и null строка");
                string empty = "";
                string nullString = null;
                var str1 = string.IsNullOrEmpty(empty);
                Console.WriteLine(str1);
                var str2 = string.IsNullOrEmpty(nullString);
                Console.WriteLine(str2);
            }
            the_second_с();
            static void the_second_d()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("г) Строка на основе StringBuilder");
                StringBuilder sb = new StringBuilder("Привет, мир"); //выделяется больше памяти, чем надо строке
                Console.WriteLine(sb);
                sb.Append(" и StringBuilder!");
                Console.WriteLine(sb);
                sb.Remove(8, 6);
                Console.WriteLine(sb);
                sb.Insert(0, "Новые символы: ");
                Console.WriteLine(sb);
            }
            the_second_d();
            static void the_third_a()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("3. а) Отформатированный двумерный массив");
                int[,] mas = { { 2, 4, 5 }, { 1, 9, 6 }, { 0, 8, 3 } };
                int rows = mas.GetUpperBound(0) + 1;//возвращает индекс последнего элемента в определенной размерности
                int columns = mas.Length / rows;
                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < columns; j++)
                    {
                        Console.Write($"{mas[i, j]}\t");
                    }
                    Console.WriteLine();
                }
            }
            the_third_a();
            static void the_third_b()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("б) Одномерный массив строк");
                string[] mas = { "abc", "def", "hij", "klm" };
                foreach (string str in mas)
                {
                    Console.Write($"{str} ");
                }
                Console.WriteLine();
                Console.WriteLine(mas.Length);
                Console.WriteLine("Введите позицию и значение");
                int pos = int.Parse(Console.ReadLine());
                string val = Console.ReadLine();
                mas[pos] = val;
                foreach (string str in mas)
                {
                    Console.Write($"{str} ");
                }
                Console.WriteLine();
            }
            the_third_b();
            Console.WriteLine("------------------------");
            Console.WriteLine("в) Ступенчатый массив");
            static void the_third_c()
            {
                //объявляем ступенчатый массив
                int[][] mas = new int[3][];
                mas[0] = new int[2];
                mas[1] = new int[3];
                mas[2] = new int[4];

                //инициализируем ступенчатый массив
                Console.WriteLine("Введите 2 числа через Enter");
                for (int i = 0; i < 2; i++)
                {
                    mas[0][i] = int.Parse(Console.ReadLine());

                }
                Console.WriteLine();

                Console.WriteLine("Введите 3 числа через Enter");
                for (int i = 0; i < 3; i++)
                {
                    mas[1][i] = int.Parse(Console.ReadLine());

                }
                Console.WriteLine();

                Console.WriteLine("Введите 4 числа через Enter");
                for (int i = 0; i < 4; i++)
                {
                    mas[2][i] = int.Parse(Console.ReadLine());

                }
                Console.WriteLine();

                for (int i = 0; i < 2; i++)
                {
                    Console.Write("{0}\t", mas[0][i]);

                }
                Console.WriteLine();

                for (int i = 0; i < 3; i++)
                {
                    Console.Write("{0}\t", mas[1][i]);

                }
                Console.WriteLine();

                for (int i = 0; i < 4; i++)
                {
                    Console.Write("{0}\t", mas[2][i]);

                }

                Console.WriteLine();
            }
            the_third_c();
            Console.WriteLine("------------------------");
            Console.WriteLine("г) Неявно тип-ые пер-ые для хр-я массива и строки");
            static void the_third_d()
            {
                var x = new[] { 1, 2, 3 };
                var y = "one";
                Console.WriteLine(y);
                foreach (var a in x)
                {
                    Console.WriteLine(a);
                }
            }
            the_third_d();

            static void the_fourth()
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("4. Кортежи и работа с ними");
                (int one, string two, char three, string four, ulong five) tuple = (125, "twenty", '#', "five", 225);
                Console.WriteLine(tuple);//вывод целиком          
                Console.WriteLine(tuple.one + " " + tuple.three + " " + tuple.four); //вывод выборочно
                var x = tuple.Item2; //распаковка в переменную
                Console.WriteLine(x);
                (int one, string two, char three, string four, ulong five) TUPLE = (120, "fifty", '#', "two", 220);
                Console.WriteLine(TUPLE == tuple); //сравнение
            }
            the_fourth();

            Console.WriteLine("------------------------");
            Console.WriteLine("5. Локальная функция");
            (int, int, int, char) the_fifth(int[] mas, string str)
            {
                return (mas.Max(), mas.Min(), mas.Sum(), str[0]);
            }
            int[] mas = { 1, 2, 3, 4, 5 };
            string str = "one";
            Console.WriteLine(the_fifth(mas, str));


        }
    }
}
