﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba5
{
    // Инвентарь, Скамейка, Брусья, Мяч, Маты, Баскетбольный мяч, Теннис.
    //добавлены Теннисный мяч, Теннисная ракетка и Теннисный корт

    interface Ifor_methods
    {
        void Method();
    }

    interface IActions_for_inventary
    {
        void Take();
        void Put();
    }

    interface IFor_tennis_ball
    {
        void for_tennis_ball();
    }


    public abstract class Inventory
    {
        public string Name { get; set; }
        public virtual void Item()
        {
            Console.WriteLine("Inventory.");
        }
        public abstract void Method();
    }

    public class Bench : Inventory, Ifor_methods  //скамейка
    {

        public string Material { get; set; }
        public override void Item()
        {
            Console.WriteLine("This inventory is a bench.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-скамейка (абстрактный класс).");
        }

        void Ifor_methods.Method()
        {
            Console.WriteLine("Этот инвентарь-скамейка (интерфейс).");
        }

        public Bench (string name, string material)
        {
            Name = name;
            Material = material;
        }

        public override string ToString()
        {
            return ($"Name: {Name} \nMaterial: {Material} ");
        }
        public override int GetHashCode()
        {
            Console.WriteLine(Name.GetHashCode());
            return Name.GetHashCode();
        }
        public override bool Equals(object obj)
        {
            if (obj.GetType() != this.GetType()) return false;
            Bench bench = (Bench)obj;
            return (Material == bench.Material);
        }

    }

    public class Bars:Inventory,IActions_for_inventary  //брусья
    {
        public int Height { get; set; }
        public override void Item()
        {
            Console.WriteLine("This inventory is a bar.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-брусья.");
        }
        public Bars(string name, int height)
        {
            Name = name;
            Height = height;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nHeight: {Height} cm");
        }
        void IActions_for_inventary.Take()
        {
            Console.WriteLine("Вы выбрали брусья для занятий спортом.");
        }

        void IActions_for_inventary.Put()
        {
            Console.WriteLine("Вы закончили занятия спортом на брусьях.");
        }
    }

    public class Mats : Inventory
    {
        public int Width { get; set; }
        public override void Item()
        {
            Console.WriteLine("This inventory is a mat.");
        }
        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-мат.");
        }
        public Mats(string name, int width)
        {
            Name = name;
            Width = width;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nWidth: {Width} cm");
             
        }
    }

    public class Balls : Inventory
    {
        public string Color { get; set; }
        public int Count { get; set; }
        public override void Item()
        {
            Console.WriteLine("This inventory is a ball.");
        }
        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-мяч.");
        }
       
        public Balls(string name, int count)
        {
            Name = name;
            Count = count;
        }


        public override string ToString()
        {
            return ($"Name: {Name} \nCount: {Count} ");
        }
    }

    public class Basketball_ball : Balls 
    {
        public override void Item()
        {
            Console.WriteLine("This inventory is a basketball ball.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-баскетбольный мяч.");
        }
        public Basketball_ball(string name,int count, string color) : base(name,count)   
        {
            
            Color = color;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nCount: {Count}\nColor: {Color} ");
        }

    }

    public sealed class Tennis_ball:Balls, IFor_tennis_ball   
    {
        public override void Item()
        {
            Console.WriteLine("This inventory is a tennis ball.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-теннисный мяч.");
        }
        public Tennis_ball(string name, int count, string color) : base(name, count) 
        {
            Color = color;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nCount: {Count}\nColor: {Color} ");
        }
        void IFor_tennis_ball.for_tennis_ball()
        {
            Console.WriteLine($"Вы играете в теннис.");
        }
    }

    public abstract class Tennis
    {
        public string Name { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public virtual void Price_of_item()
        {
            Console.WriteLine("Price.");
        }
        public abstract void Method();
    }

    public class Tennis_court : Tennis
    {

        public override void Price_of_item()
        {
            Console.WriteLine("Tennis court price is 290 BYN sq.m.");
        }
        public override void Method()
        {
            Console.WriteLine("This item is a tennis court.");
        }
        public Tennis_court(string name, double width, double height)
        {
            Name = name;
            Width = width;
            Height = height;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nWidth: {Width} cm\nHeight: {Height} cm");
        }
    }

    public class Tennis_racquet : Tennis
    {
        public override void Price_of_item()
        {
            Console.WriteLine("Tennis court price is 300 BYN.");
        }
        public override void Method()
        {
            Console.WriteLine("This item is a tennis racquet.");
        }
        public Tennis_racquet(string name, double height)
        {
            Name = name;
            Height = height;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nHeight: {Height} cm");
        }
    }
    
    public class Printer
    {
        public void IAmPrinting(Inventory someobj)
        {
            if (someobj is Inventory)
            {
                Console.WriteLine(someobj.ToString());
            }
            else if (someobj is Bench)
            {

                Console.WriteLine(someobj.ToString());
            }
            else if (someobj is Bars)
            {

                Console.WriteLine(someobj.ToString());
            }

            else if (someobj is Mats)
            {

                Console.WriteLine(someobj.ToString());
            }
            else if (someobj is Balls)
            {

                Console.WriteLine(someobj.ToString());
            }
            else if (someobj is Basketball_ball)
            {

                Console.WriteLine(someobj.ToString());
            }
            else if (someobj is Tennis_ball)
            {

                Console.WriteLine(someobj.ToString());
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-------ИЕРАРХИЯ НАСЛЕДОВАНИЯ ОТ ИНВЕНТАРЯ-------");
            Console.WriteLine();
            Console.WriteLine("----Скамейка----");
            Bench bench1 = new Bench("скамейка №1", "дерево");
            Bench bench2 = new Bench("скамейка №2", "дерево");
            Bench bench3 = new Bench("скамейка №3", "сталь");
            Ifor_methods bench = bench1;
            bench1.Item();
            bench1.Method();
            bench.Method();
            Console.WriteLine(bench1.ToString());
            Console.WriteLine(bench1.Equals(bench2));
            Console.WriteLine(bench1.Equals(bench3));
            bench1.GetHashCode();
            Console.WriteLine("Оператор is для bench1 is Bench: " + (bench1 is Bench));
            Console.WriteLine();


            Console.WriteLine("----Брусья----");
            Bars bar = new Bars("брусья", 140);
            IActions_for_inventary bar1 = bar;
            bar.Item();
            bar.Method();
            Console.WriteLine(bar.ToString());
            bar1.Take();
            bar1.Put();
            Console.WriteLine();


            Console.WriteLine("----Маты----");
            Mats mat = new Mats("мат", 10);
            mat.Item();
            mat.Method();
            Console.WriteLine(mat.ToString());
            Console.WriteLine();

            Console.WriteLine("----Мячи---");
            Balls balls = new Balls("мяч", 5);
            balls.Item();
            balls.Method();
            Console.WriteLine(balls.ToString());
            Console.WriteLine();


            Console.WriteLine("----Баскетбольный мяч---");
            Basketball_ball ball1 = new Basketball_ball("баскетбольный мяч", 4,"оранжевый");
            ball1.Item();
            ball1.Method();
            Console.WriteLine(ball1.ToString());
            Console.WriteLine();


            Console.WriteLine("----Теннисный мяч---");
            Tennis_ball ball2 = new Tennis_ball("теннисный мяч", 1,"желтый");
            IFor_tennis_ball ball3 = ball2;
            ball2.Item();
            ball2.Method();
            Console.WriteLine(ball2.ToString());
            ball3.for_tennis_ball();
            Console.WriteLine();
            ball1 = balls as Basketball_ball;
            if (ball1 == null)
            {
                Console.WriteLine("Невозможно привести balls к типу Basketball_ball.");
            }
            else
            {
                Console.WriteLine("Можно привести balls к типу Basketball_ball.");
            }
            
            balls = ball2 as Balls; 
            if (balls == null)
            {
                Console.WriteLine("Невозможно привести ball2 к типу Balls.");
            }
            else
            {
                Console.WriteLine("Можно привести ball2 к типу Balls.");
            }
            Console.WriteLine();

            Console.WriteLine("-------ИЕРАРХИЯ НАСЛЕДОВАНИЯ ОТ ТЕННИСА-------");
            Console.WriteLine();
            Console.WriteLine("----Теннисный корт---");
            Tennis_court court = new Tennis_court("теннисный корт", 8.23, 23.77);
            court.Price_of_item();
            court.Method();
            Console.WriteLine(court.ToString());
            Console.WriteLine();


            Console.WriteLine("----Теннисная ракетка---");
            Tennis_racquet racquet = new Tennis_racquet("теннисная ракетка", 68.6);
            racquet.Price_of_item();
            racquet.Method();
            Console.WriteLine(racquet.ToString());
            Console.WriteLine();


            Console.WriteLine("----Массив---");
            Bench bench0 = new Bench("Скамейка", "дерево");
            Bars bar0 = new Bars("Брусья", 120);
            Mats mat0 = new Mats("Мат", 15);
            Balls ball0 = new Balls("Мячи", 2);
            var array = new Inventory[4];
            Printer printer = new Printer();
            array[0] = bench0;
            array[1] = bar0;
            array[2] = mat0;
            array[3] = ball0;
            foreach(var someobj in array)
            {                        
                printer.IAmPrinting(someobj);
                Console.WriteLine();
            }


        }
    }
}
