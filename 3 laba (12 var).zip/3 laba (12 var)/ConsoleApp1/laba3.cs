﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba3
{
    public partial class Bus
    {
        
        private string name { get; set; }
        public int bus_number { get; private set; }
        public int route_number { get; set; }
        private const string bus_brand= "Mercedes-Benz";  
        private int Year;
        public int year
        {
            get
            {
                return Year;
            }
            set
            {
                Year = value;
            }
        }
    
    private int mileage { get; set; }
        private static int counter = 0;
        public readonly Guid id; 
                
        public Bus(string name, int bus_number, int mileage, int route_number) //конструктор с параметрами
        {
            if (!String.IsNullOrEmpty(name) && bus_number > 0 && route_number > 0)
            {
                
                this.name = name;
                this.bus_number = bus_number;
                this.mileage = mileage;
                this.route_number = route_number;
                id = Guid.NewGuid();
                counter++;
                Console.WriteLine($"Номер объекта: {counter}");
            }
            else
                Console.WriteLine("Перепроверьте данные!\n");
        }

        public Bus(string name, int route_number = 333, int mileage = 125000) //конструктор с параметрами по умолчанию
        {
            if (!String.IsNullOrEmpty(name) && route_number > 0 && mileage > 0)
            {
                bus_number = 5858;
                this.name = name;
                this.route_number = route_number;
                this.mileage = mileage;
                counter++;
                Console.WriteLine($"Номер объекта: {counter}");
                id = Guid.NewGuid();
            }
            else
                Console.WriteLine("Перепроверьте данные!\n");
               

        }

        
        static Bus()  //статический конструктор
        {
            Console.WriteLine($"Статический конструктор, создан первый объект"); /*вызывается автоматически перед созданием первого экземпляра 
                                                                                                       * или ссылкой на какие-либо статические члены и только один раз */
            
            Console.WriteLine(); //можем обращаться только к статическим полям

        }

        public static void DisplayCounter()  //статический метод для подсчета кол-ва объектов класса Bus
        {
            Console.WriteLine($"Создано объектов Bus: {counter} ");
        }

        private Bus() //закрытый конструктор, конструктор без параметров
        {
            

                bus_number = 7722;
                mileage = 8000;
                id = Guid.NewGuid();
                counter++;
                Console.WriteLine($"Номер объекта: {counter}");
            // здесь какая-то базовая инициализация
            // этот конструктор должен быть вызван из конструкторов дочерних классов

        }

        public class SubBus : Bus
        {

            public SubBus() : base()
            {                    
                name = "Гордеев М.А.";
               
            }
        }

        public void getRoute_numberRef(ref int route_number)
        {
           route_number++;
        }

        public void getRoute_numberOut(out int route_number)
        {
            route_number = this.route_number;
            
        }

        public override bool Equals(object obj)
        {
            if (obj.GetType() != this.GetType()) return false;
            Bus bus = (Bus)obj;
            return (this.route_number == bus.route_number);
        }

        public override int GetHashCode() 
        {
            return bus_number;
        }


        public override string ToString()
        {
            return ($"Фамилия и инициалы водителя: {this.name} \nНомер автобуса: {this.bus_number} \nНомер маршрута: {this.route_number} " +
                $"\nМарка: {bus_brand} \nГод начала эксплуатации: {this.year} \nПробег: {this.mileage} км \nID: {this.id}" );
        }

    }
    //index
    class BUS
    {
        public string Name { get; set; }

    }
    class PARK_BUS
    {
        BUS[] data;
        public PARK_BUS()
        {
            data = new BUS[5];
        }
        public BUS this[int index]  //индексатор
        {
            get
            {
                return data[index];   //место хранения всех объектов
            }
            set
            {
                data[index] = value;
            }
        }

    }
    class Program
    {
        static void Main(string[] args)
        {

            Bus.SubBus bus1 = new Bus.SubBus(); //закрытый конструктор
            bus1.year = 2018;
            bus1.route_number = 111;
            bus1.Info();
            bus1.bus_age();
            Console.WriteLine();
            Console.WriteLine();
                        
            Bus bus2 = new Bus("Панов И.А.", 2438, 150000,222); //активируется статический конструктор до выполенения конструктора экземпляра
            bus2.year = 2012;
            Console.WriteLine(bus2.ToString());
            bus2.bus_age();
            Console.WriteLine("Тип объекта: " + bus2.GetType());
            Console.WriteLine();
            Console.WriteLine();

            
            Bus bus3 = new Bus("Трофимов А.В.");
            bus3.year = 2015;
            bus3.Info();
            bus3.bus_age();
            Console.WriteLine();
            Console.WriteLine();


            Bus bus4 = new Bus("Иванов М.А.", 2312,175000,444); 
            bus4.year = 2012;
            Console.WriteLine(bus4.ToString());
            bus4.bus_age();
            Console.WriteLine();
            Console.WriteLine();

            Bus.DisplayCounter();

            int route_number_ref = 554;
            bus3.getRoute_numberRef(ref route_number_ref);
            Console.WriteLine($"Ref: {route_number_ref}");

            bus3.getRoute_numberOut(out int route_number_out);
            Console.WriteLine($"Out: {route_number_out}");

            Console.WriteLine("Equals (bus2 & bus4): "+bus2.Equals(bus4));
           

            Console.WriteLine("GetHashCode for route_number: "+bus4.GetHashCode());

            Bus[] BusArray = { bus2, bus3, bus4 };
            Console.WriteLine("\nВведите номер маршрута");
            int x= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            foreach (var bus in BusArray)
            {
                if (bus.route_number == x)
                {
                    Console.WriteLine(bus.ToString());
                }
            }

            Console.WriteLine("\nВведите срок эксплуатации");
            int y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            foreach (var bus in BusArray)
            {
                if ((2021-bus.year) > y)
                {
                    Console.WriteLine(bus.ToString()+"\nСрок эксплуатации: "+(2021-bus.year)+"\n");
                }
            }
            var anon = new { Name = "Хилько", bus_number = 2436, route_number = 1010};
            Console.WriteLine(anon.GetType());

            //index
            PARK_BUS park_bus = new PARK_BUS();
            park_bus[0] = new BUS
            {
                Name = "Первый"
            };

            park_bus[1] = new BUS
            {
                Name = "Второй"
            };

            BUS first = park_bus[0];
            Console.WriteLine(first.Name);

        }
    }
}
