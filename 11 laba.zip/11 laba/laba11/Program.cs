﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba11
{

 
    
    class Program
    {
        static void Main(string[] args)
        {
           /* //1 ЗАДАНИЕ
            //массив
            string[] months = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            Console.WriteLine("Исходный массив месяцев: ");
            foreach (string month in months)
            {
                Console.Write(month+" ");
            }


            Console.WriteLine("\n\nВведите длину строки n: ");/*запрос, выбирающий последовательность 
                                                          месяцев с длиной строки равной n*/
            /*int n = Convert.ToInt32(Console.ReadLine());
            var months_n = from month in months
                           where month.Length == n
                           select month;
            foreach (string month in months_n)
            {
                Console.Write(month + " ");
            }


            var months_sum_win = from month in months  //летние и зимние месяцы
                                      where Array.IndexOf(months, month) < 2 ||
                                      Array.IndexOf(months, month) > 4 && Array.IndexOf(months, month) < 8 ||
                                      Array.IndexOf(months, month) == 11
                                      select month;
            Console.WriteLine("\n\nЗимние и летние месяцы:");
            foreach (string month in months_sum_win)
            {
                Console.Write(month + " ");
            }


            var months_in_alphabet_order = from month in months //месяцы в алф. порядке
                                           orderby month
                                           select month;
            Console.WriteLine("\n\nВывод месяцев в алфавитном порядке:");
            foreach (string month in months_in_alphabet_order)
            {
                Console.Write(month + " ");
            }

            var months_containsU_4 = from month in months//последний запрос для месяцев
                                  where month.Contains('u') && month.Length > 3
                                  select month;
            Console.WriteLine("\n\nМесяцы, содержащие букву «u» и длиной имени не менее 4-х:");
            foreach (string month in months_containsU_4)
                Console.Write(month + " ");*/

            
            //2 ЗАДАНИЕ
            



        }
    }
}
