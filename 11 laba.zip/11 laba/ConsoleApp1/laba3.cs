﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba3
{
    public class Person
    {
        public string color { get; set; }
        public int bus_number { get; private set; }
        public Person(int bus_number, string color)
        {
            this.bus_number = bus_number;
            this.color = color;
        }
        
    }
    public partial class Bus
    {
        
        public string name { get; set; }
        public int bus_number { get; private set; }
        public int route_number { get; set; }
        private const string bus_brand= "Mercedes-Benz";  
        private int Year;
        public int year
        {
            get
            {
                return Year;
            }
            set
            {
                Year = value;
            }
        }
    
        public int mileage { get; set; }
        private static int counter = 0;
        public readonly Guid id; 
                
        public Bus(string name, int bus_number, int mileage, int route_number, int year) //конструктор с параметрами
        {
            if (!String.IsNullOrEmpty(name) && bus_number > 0 && route_number > 0)
            {
                this.year = year;
                this.name = name;
                this.bus_number = bus_number;
                this.mileage = mileage;
                this.route_number = route_number;
                id = Guid.NewGuid();
                counter++;
            }
            else
                Console.WriteLine("Перепроверьте данные!\n");
        }

        public Bus(string name, int route_number = 333, int mileage = 125000) //конструктор с параметрами по умолчанию
        {
            if (!String.IsNullOrEmpty(name) && route_number > 0 && mileage > 0)
            {
                bus_number = 5858;
                this.name = name;
                this.route_number = route_number;
                this.mileage = mileage;
                counter++;
                id = Guid.NewGuid();
            }
            else
                Console.WriteLine("Перепроверьте данные!\n");
               

        }

        
       

        public static void DisplayCounter()  //статический метод для подсчета кол-ва объектов класса Bus
        {
            Console.WriteLine($"Создано объектов Bus: {counter} ");
        }

        private Bus() //закрытый конструктор, конструктор без параметров
        {
            

                bus_number = 7722;
                mileage = 8000;
                id = Guid.NewGuid();
                counter++;
                
            // здесь какая-то базовая инициализация
            // этот конструктор должен быть вызван из конструкторов дочерних классов

        }

        public class SubBus : Bus
        {

            public SubBus() : base()
            {                    
                name = "Гордеев М.А.";
               
            }
        }

        public void getRoute_numberRef(ref int route_number)
        {
           route_number++;
        }

        public void getRoute_numberOut(out int route_number)
        {
            route_number = this.route_number;
            
        }

        public override bool Equals(object obj)
        {
            if (obj.GetType() != this.GetType()) return false;
            Bus bus = (Bus)obj;
            return (this.route_number == bus.route_number);
        }

        public override int GetHashCode() 
        {
            return bus_number;
        }


        public override string ToString()
        {
            return ($"\nФамилия и инициалы водителя: {this.name} \nНомер автобуса: {this.bus_number} \nНомер маршрута: {this.route_number} " +
                $"\nГод начала эксплуатации: {this.year} \nПробег: {this.mileage} км " );
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--------11 ЛАБА--------");
            Console.WriteLine("\n---1 ЗАДАНИЕ---");

            //1 ЗАДАНИЕ
            //массив
            string[] months = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
           Console.WriteLine("Исходный массив месяцев: ");
           foreach (string month in months)
           {
               Console.Write(month+" ");
           }


           Console.WriteLine("\n\nВведите длину строки n: ");/*запрос, выбирающий последовательность 
                                                         месяцев с длиной строки равной n*/
            int n = Convert.ToInt32(Console.ReadLine());
            var months_n = from month in months
                           where month.Length == n
                           select month;
            foreach (string month in months_n)
            {
                Console.Write(month + " ");
            }


            var months_sum_win = from month in months  //летние и зимние месяцы
                                      where Array.IndexOf(months, month) < 2 ||
                                      Array.IndexOf(months, month) > 4 && Array.IndexOf(months, month) < 8 ||
                                      Array.IndexOf(months, month) == 11
                                      select month;
            Console.WriteLine("\n\nЗимние и летние месяцы:");
            foreach (string month in months_sum_win)
            {
                Console.Write(month + " ");
            }


            var months_in_alphabet_order = from month in months //месяцы в алф. порядке
                                           orderby month
                                           select month;
            Console.WriteLine("\n\nВывод месяцев в алфавитном порядке:");
            foreach (string month in months_in_alphabet_order)
            {
                Console.Write(month + " ");
            }

            var months_containsU_4 = from month in months//последний запрос для месяцев
                                  where month.Contains('u') && month.Length > 3
                                  select month;
            Console.WriteLine("\n\nМесяцы, содержащие букву «u» и длиной имени не менее 4-х:");
            foreach (string month in months_containsU_4)
                Console.Write(month + " ");
            Console.WriteLine();


            //2 ЗАДАНИЕ
            Console.WriteLine("\n---2 ЗАДАНИЕ---");
            List<Bus> buses = new List<Bus>();
            buses.Add(new Bus("Воробьев А.А.", 2438, 110000, 111,2010));
            buses.Add(new Bus("Михайлов Н.В.", 7220, 170000, 222,2015));
            buses.Add(new Bus("Жуков В.А.", 4856, 130000, 666,2016));
            buses.Add(new Bus("Самсонов А.Н.", 5880, 140000, 444,2018));
            buses.Add(new Bus("Терентьев Е.А.", 3855, 180000, 555,2019));
            buses.Add(new Bus("Трофимов Д.Г.", 1648, 120000, 111,2011));
            buses.Add(new Bus("Гордеев Д.В.", 2312, 160000, 666,2014));
            buses.Add(new Bus("Белов М.А.", 1856, 150000, 888,2008));
            foreach (Bus bus in buses)
               Console.WriteLine(bus.ToString());


            //3 ЗАДАНИЕ
            Console.WriteLine("\n---3 ЗАДАНИЕ---");
            //список автобусов для заданного номера маршрута
            Console.WriteLine("\n\nСписок номеров автобусов для заданного номера маршрута:");
            Console.WriteLine("Введите номер маршрута: ");
            int route = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            foreach (var bus in buses.Where(bus => bus.route_number == route))
            {
                Console.WriteLine(bus.bus_number);
            }


            //список автобусов для заданного номера маршрута список автобусов, которые эксплуатируются заданного срока
            Console.WriteLine("\nCписок автобусов, которые эксплуатируются больше заданного срока:");
            Console.WriteLine("Введите срок эксплуатации: ");
            int years = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            foreach (var bus in buses.Where(bus=>2021-bus.year>years))
            {
                Console.WriteLine(bus.bus_number);
            }


            //минимальный по пробегу автобус
            Console.WriteLine("\nМинимальный по пробегу автобус:");
            Console.WriteLine(buses.Single(i=>i.mileage==buses.Min(bus=>bus.mileage)).bus_number);


            //последние два автобуса максимальные по пробегу
            Console.WriteLine("\nПоследние два автобуса максимальные по пробегу:");
            Console.WriteLine(buses.OrderByDescending(i => i.mileage).ToList()[0].bus_number);
            Console.WriteLine(buses.OrderByDescending(i => i.mileage).ToList()[1].bus_number);


            //упорядоченный список автобусов по номеру 
            Console.WriteLine("\nУпорядоченный список автобусов по номеру:");
            foreach (var bus in buses.OrderBy(bus => bus.bus_number))
            {
                Console.WriteLine(bus.bus_number);
            }


            //4 ЗАДАНИЕ
            Console.WriteLine("\n---4 ЗАДАНИЕ---");
            int request = buses.OrderBy(bus => bus.mileage).Where(bus => 2021-bus.year < 10).Take(4).Skip(2).Sum(bus=>bus.mileage);
            Console.WriteLine("\nРезультат собственного запроса: "+request);
            //where-условие
            //orderBy-упорядочивание
            //sum-агрегирование
            //take,skip-разбиение


            //5 ЗАДАНИЕ
            Console.WriteLine("\n---5 ЗАДАНИЕ---");
            Console.WriteLine("\nРезультат запроса с оператором Join: ");
            List <Bus> busList = new List<Bus>();
            busList.Add(new Bus("Гордеев Д.В.", 2312, 160000, 666, 2014));
            busList.Add(new Bus("Самсонов А.Н.", 5880, 140000, 444, 2018));

            var personList = new List<Person>();
            personList.Add(new Person(2312, "черный"));
            personList.Add(new Person(5880, "серый"));
            //Объекты обоих классов имеют один общий критерий - bus_number. По нему и соединяем.
            var join = from person in personList
                         join bus in busList on person.bus_number equals bus.bus_number
                         select new { Color = person.color, Bus_number = person.bus_number, Year = bus.year, Name=bus.name };

            foreach (var item in join)
            {
                Console.WriteLine($"{item.Name} - {item.Bus_number} ({item.Color}).Автобус {item.Year} года выпуска. ");
            }



        }
    }
}
