﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba3
{
    public partial class Bus
        /*мы можем иметь несколько файлов с определением одного и того же класса, и при 
         * компиляции все эти определения будут скомпилированы в одно*/
    {
        public void bus_age()
        {
            int x = 2021 - year;
           
                Console.WriteLine("Возраст автобуса: " + x);
          
        }
        public void Info()
        {
            Console.WriteLine($"Фамилия и инициалы водителя: {this.name} \nНомер автобуса: {this.bus_number} \nНомер маршрута: {this.route_number} " +
                $"\nМарка: {bus_brand} \nГод начала эксплуатации: {this.year} \nПробег: {this.mileage} км \nID: {this.id}");
        }
    }
}
