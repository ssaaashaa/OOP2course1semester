﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba4
{
    public class List
    {
        public List<int> list = new List<int>();  

        
        public void Output() //метод вывода списка
        {
            foreach (int i in list)
            {
                Console.WriteLine(i);
            }
        }

        public void Reverse() //метод инверсии списка
        {
            list.Reverse();
        }

        public void Add(int element) //метод добавления элемента в список
        {
            list.Add(element);
        }

        public int Count() //метод возвращает количество элементов списка
        {
            return list.Count();
        }

        public int Element(int i) //метод возвращает элемент списка
        {
            return list[i];
        }

        public void Delete(int element) //метод удаления элемента из списка
        {
            list.RemoveAt(element);
        }


        public static List operator !(List list1) //перегрузка операторов-инверсия элементов
        {
            list1.Reverse();
            return list1;
        }



        public static List operator +(List list1, List list2) //перегрузка операторов-объединенеие двух списков
        {
            List UnitedList = new List();
            for (int i = 0; i < list1.Count(); i++)
            {
                int element = list1.Element(i);
                UnitedList.Add(element);
            }
            for (int i = 0; i < list2.Count(); i++)
            {
                int element = list2.Element(i);
                UnitedList.Add(element);
            }
            for (int i=0; i < UnitedList.Count();i++)
            {
                for (int j = i+1; j < UnitedList.Count(); j++)
                {
                    if (UnitedList.Element(i) == UnitedList.Element(j))
                    {
                        UnitedList.Delete(j);
;                   }

                }
            }
            return UnitedList;

            
        }



        public static bool operator ==(List list1, List list2) //перегрузка операторов-сравнение двух списков
        {
            int count = 0;
            if (list1.Count() != list2.Count()) return false;
            else
            {
                for (int i = 0; i < list1.Count(); i++)
                {
                    if (list1.Element(i) == list2.Element(i)) count += 1;
                }
                if (count == list1.Count()) return true;
                else return false;
            }
        }
        public static bool operator !=(List list1, List list2) 
        {
            int count = 0;
            if (list1.Count() != list2.Count()) return true;
            else
            {
                for (int i = 0; i < list1.Count(); i++)
                {
                    if (list1.Element(i) == list2.Element(i)) count += 1;
                }
                if (count == list1.Count()) return false;
                else return true;
            }
        }



        public static List operator <(List list1, List list2) //перегрузка операторов-добавление одного списка к другому
        {
            for (int i = 0; i < list2.Count(); i++)
            {
                int element = list2.Element(i);
                list1.Add(element);
            }
            return list1;
        }
        public static List operator >(List list1, List list2) 
        {
            for (int i = 0; i < list1.Count(); i++)
            {
                int element = list1.Element(i);
                list2.Add(element);
            }
            return list2;
        }



        public class Owner// вложеный объект Owner 
        {
            public readonly Guid id;
            public string name;
            public string university;
            public Owner()   //конструктор
            {
                id = Guid.NewGuid();
                name = "Aleksandra";
                university = "BSTU";
            }

           public override string ToString()  //вывод
            {
                return $"ID: {id}\nName: {name}\nUniversity: {university}";
            }
           
        }
        public class Date  //вложенный класс Date
        {
            public DateTime date;

            public Date()  //конструктор
            {
                date = DateTime.Now;
            }

            public override string ToString()  //вывод
            {
                return $"Дата: {date}";
            }
        }

    }
    public static class StatisticOperation
    {
        public static int Sum(List list_sum) //статический метод-сумма
        {
           
            int sum = list_sum.list.ToArray().Sum();
            return sum;
            
        }
        public static int Max_minus_Min(List list_minus) //статический метод-разница между макс. и мин.
        {
            
            int min = list_minus.list.ToArray().Min();
            int max = list_minus.list.ToArray().Max();
            int minus = max - min;
            return minus;

        }
        public static void Count_of_el(List list_count) //статический метод-кол-во эл-тов списка
        {
            Console.WriteLine($"Количество элементов нового списка: {list_count.Count()}");
        }




        public static string Truncation(this string str) //метод расширения string-усечение строки до заданной длины
        {
            string NewString = null;
            Console.WriteLine("Введите значение: ");
            int length = int.Parse(Console.ReadLine());
            if (length < str.Length)
            {
                for (int i = 0; i < length; i++)
                {
                    NewString += str[i];
                }
                Console.WriteLine($"Усечение строки до заданного значения: {NewString}");
                return null;
            }
            else Console.WriteLine($"Усечение строки невозможно из-за некорректного значения! Строка: {str}");
            return null;
        }



        public static int Sum_extention(this List list_Sum) //метод расширения-сумма элементов списка
        {
            int Sum = 0;
            for (int i = 0; i < list_Sum.Count(); i++)
            {
                Sum += list_Sum.Element(i);
            }
            Console.WriteLine($"Cумма элементов нового списка: {Sum}");
            return 0;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List.Owner owner = new List.Owner();
            Console.WriteLine(owner.ToString());
            List.Date date = new List.Date();
            Console.WriteLine(date.ToString());
            Console.WriteLine();
            List List1 = new List();
            List List2 = new List();
            Console.WriteLine("Первый список: ");
            List1.Add(1);
            List1.Add(2);
            List1.Add(3);
            List1.Add(4);
            List1.Add(5); 

            List1.Output();
            Console.WriteLine();
            Console.WriteLine("Второй список: ");
            List2.Add(1);
            List2.Add(7);
            List2.Add(8);
            List2.Add(7);
            List2.Add(10);
            List2.Output();
            Console.WriteLine();
            Console.WriteLine("Инверсия элементов 1-ого списка(!): ");
            List List = !List1;
            List.Output();
            List list = !List1;
            Console.WriteLine();
            Console.WriteLine("Объединение двух списков(+): ");
            List UnitedList = List1 + List2;
            UnitedList.Output();
            Console.WriteLine();
            if (List1 == List2) Console.WriteLine("Равенство списков(==): списки равны.");
            else Console.WriteLine("Равенство списков(==): списки не равны.");
            Console.WriteLine();
            Console.WriteLine("Добавление одного списка к другому(<): ");
            List2 = List1 < List2;
            List2.Output();
            Console.WriteLine();
            List NewList = new List();
            Console.WriteLine("Новый список: ");
            NewList.Add(20);
            NewList.Add(10);
            NewList.Add(30);
            NewList.Add(50);
            NewList.Add(40);
            NewList.Output();
            Console.WriteLine();
            int sum=StatisticOperation.Sum(NewList);
            Console.WriteLine($"Cумма элементов нового списка: {sum}");
            Console.WriteLine();
            int minus=StatisticOperation.Max_minus_Min(NewList);
            Console.WriteLine($"Разница максимального и минимального элементов нового списка: {minus}");
            Console.WriteLine();
            StatisticOperation.Count_of_el(NewList);
            Console.WriteLine();
            Console.WriteLine("Методы расширения: ");
            string str = "Visual Studio 2019";
            Console.WriteLine($"Строка до усечения: {str}");
            str.Truncation();
            Console.WriteLine();
            Console.WriteLine("Новый список: ");
            NewList.Output();
            NewList.Sum_extention();




        }
    }

}
