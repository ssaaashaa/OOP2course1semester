﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Xml.Serialization;
using Newtonsoft.Json;
using System.Xml;
using System.Xml.Linq;



namespace laba12
{
    interface Ifor_methods
    {
        void Method();
    }

    [Serializable]
    public abstract class Inventory
    {
        public string Name { get; set; }
        public virtual void Item()
        {
            Console.WriteLine("Inventory.");
        }
        public abstract void Method();
    }

    [Serializable]
    public class Bench : Inventory, Ifor_methods  //скамейка
    {
        public Bench() { }
        public string Material { get; set; }
        public override void Item()
        {
            Console.WriteLine("This inventory is a bench.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-скамейка (абстрактный класс).");
        }

        void Ifor_methods.Method()
        {
            Console.WriteLine("Этот инвентарь-скамейка (интерфейс).");
        }

        public Bench(string name, string material)
        {
            Name = name;
            Material = material;
        }

        public override string ToString()
        {
            return ($"Name: {Name} \nMaterial: {Material} ");
        }



    }

    [Serializable]
    public class Balls : Inventory
    {
        public Balls() { }
        public string Color { get; set; }
        public int Count { get; set; }
        public override void Item()
        {
            Console.WriteLine("This inventory is a ball.");
        }
        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-мяч.");
        }

        public Balls(string name, int count)
        {
            Name = name;
            Count = count;
        }


        public override string ToString()
        {
            return ($"Name: {Name} \nCount: {Count} ");
        }
    }

    [Serializable]
    public class Basketball_ball : Balls
    {

        public override void Item()
        {
            Console.WriteLine("This inventory is a basketball ball.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-баскетбольный мяч.");
        }
        public Basketball_ball(string name, int count, string color) : base(name, count)
        {

            Color = color;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nCount: {Count}\nColor: {Color} ");
        }

    }






    class Program
    {


        static async Task Main(string[] args)
        {
            Console.WriteLine("----------------1 ЗАДАНИЕ----------------");
            //бинарный формат
            Console.WriteLine("--------Бинарный формат-------");
            //объект для сериализации
            Bench bench = new Bench("bench", "wood");
            //создаем объект BinaryFormatter
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            //сериализация
            //получаем поток, куда будем записывать сериализованный объект
            using (FileStream fs = new FileStream("data.dat", FileMode.OpenOrCreate))
            {
                binaryFormatter.Serialize(fs, bench);
                Console.WriteLine("Объект сериализован.");
            }
            //десериализация
            using (FileStream fs = new FileStream("data.dat", FileMode.OpenOrCreate))
            {
                //размещает объект в памяти и возвращает ссылку на него, конструкторы не вызываются
                Bench bench_binary = (Bench)binaryFormatter.Deserialize(fs);
                Console.WriteLine($"\nНаименование: {bench_binary.Name}.\nМатериал:{bench_binary.Material}.\nОбъект десериализован.");
            }

            //SOAP формат
            Console.WriteLine("\n--------SOAP формат-------");
            SoapFormatter soapFormatter = new SoapFormatter();
            //сериализация
            using (FileStream fs = new FileStream("data.soap", FileMode.OpenOrCreate))
            {
                soapFormatter.Serialize(fs, bench);
                Console.WriteLine("Объект сериализован.");
            }
            //десериализация
            using (FileStream fs = new FileStream("data.soap", FileMode.OpenOrCreate))
            {
                Bench bench_SOAP = (Bench)soapFormatter.Deserialize(fs);
                Console.WriteLine($"\nНаименование: {bench_SOAP.Name}.\nМатериал:{bench_SOAP.Material}.\nОбъект десериализован.");
            }

            //JSON формат
            Console.WriteLine("\n--------JSON формат-------");
            Basketball_ball basketball_Ball = new Basketball_ball("basketball ball", 5, "orange");
            //сериализация
            string json = JsonConvert.SerializeObject(basketball_Ball);    
            File.WriteAllText("data.json", json);
            Console.WriteLine("Объект сериализован.");
            //десериализация
            Basketball_ball basketball_Ball_JSON = JsonConvert.DeserializeObject<Basketball_ball>(json);
            Console.WriteLine($"\nНаименование: {basketball_Ball_JSON.Name}.\nКоличество:{basketball_Ball_JSON.Count}.\nЦвет: {basketball_Ball_JSON.Color}\nОбъект десериализован.");

            
               
            //XML формат
            Console.WriteLine("\n--------XML формат-------");
            //передаем в конструктор тип класса
            XmlSerializer xmlFormatter = new XmlSerializer(typeof(Bench));
            //сериализация
            //получаем поток, куда будем записывать сериализованный объект
            using (FileStream fs = new FileStream("data.xml", FileMode.OpenOrCreate))
            {
                xmlFormatter.Serialize(fs, bench);
                Console.WriteLine("Объект сериализован.");
            }
            //десериализация
            using (FileStream fs = new FileStream("data.xml", FileMode.OpenOrCreate))
            {
                Bench bench_XML = (Bench)xmlFormatter.Deserialize(fs);
                Console.WriteLine($"\nНаименование: {bench_XML.Name}.\nМатериал:{bench_XML.Material}.\nОбъект десериализован.");
            }


            Console.WriteLine("\n----------------2 ЗАДАНИЕ----------------");
            Balls balls1 = new Balls("balls", 2);
            Balls balls2 = new Balls("balls", 6);
            Balls balls3 = new Balls("balls", 10);
            Balls[] balls = { balls1, balls2, balls3 };
            XmlSerializer xmlFormatterArray = new XmlSerializer(typeof(Balls[]));
            //сериализация
            //получаем поток, куда будем записывать сериализованный объект
            using (FileStream fs = new FileStream("dataOfArray.xml", FileMode.OpenOrCreate))
            {
                xmlFormatterArray.Serialize(fs, balls);
                Console.WriteLine("Массив сериализован.");
            }
            //десериализация
            using (FileStream fs = new FileStream("dataOfArray.xml", FileMode.OpenOrCreate))
            {
                Balls[] inventory_XML = (Balls[])xmlFormatterArray.Deserialize(fs);
                foreach (Balls item in inventory_XML)
                    Console.WriteLine($"\nНаименование: {item.Name}.\nКоличество:{item.Count}.\nОбъект десериализован.");
            }
            Console.WriteLine("\n----------------3 ЗАДАНИЕ----------------");
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load("dataOfArray.xml");
            XmlElement xRoot = xDoc.DocumentElement;
            // выбор всех дочерних узлов
            Console.WriteLine("Вывод всех дочерних узлов: ");
            XmlNodeList childnodes1 = xRoot.SelectNodes("*");
            foreach (XmlNode n in childnodes1)
                Console.WriteLine(n.OuterXml);
            Console.WriteLine();
            Console.WriteLine("Количество мячей: ");
            XmlNodeList childnodes2 = xRoot.SelectNodes("//Balls/Count");
            foreach (XmlNode n in childnodes2)
                Console.WriteLine(n.InnerText);
            Console.WriteLine();
            Console.WriteLine("Узел, у которого вложенный элемент Count имеет значение 10");
            XmlNode childnode2 = xRoot.SelectSingleNode("Balls[Count='10']");
            if (childnode2 != null)
                Console.WriteLine(childnode2.OuterXml);
            Console.WriteLine("\n----------------4 ЗАДАНИЕ----------------");
            XDocument xdoc = new XDocument();
            // создаем первый элемент
            XElement balls_XML1 = new XElement("Balls");
            // создаем атрибут
            XAttribute ballsAttr = new XAttribute("type", "basketball ball");
            //создаем элементы
            XElement ballsElem1 = new XElement("Color", "orange");
            XElement ballsElem2 = new XElement("Count", "five");
            // добавляем атрибут и элементы в первый элемент
            balls_XML1.Add(ballsAttr);
            balls_XML1.Add(ballsElem1);
            balls_XML1.Add(ballsElem2);

            // создаем второй элемент
            XElement balls_XML2 = new XElement("Balls");
            // создаем атрибут
            XAttribute ballsAttr2 = new XAttribute("type", "tennis ball");
            //создаем элементы
            XElement ballsElem3 = new XElement("Color", "yellow");
            XElement ballsElem4 = new XElement("Count", "ten");
            balls_XML2.Add(ballsAttr2);
            balls_XML2.Add(ballsElem3);
            balls_XML2.Add(ballsElem4);
            // создаем корневой элемент
            XElement inventory = new XElement("inventory");
            // добавляем в корневой элемент
            inventory.Add(balls_XML1);
            inventory.Add(balls_XML2);
            // добавляем корневой элемент в документ
            xdoc.Add(inventory);
            //сохраняем документ
            xdoc.Save("Inventory.xml");

            XDocument xdoc1 = XDocument.Load("Inventory.xml");
            var items = from xe in xdoc1.Element("inventory").Elements("Balls")
                        where xe.Element("Color").Value == "yellow"
                        select xe;

            foreach (var item in items)
                Console.WriteLine(item);
            Console.ReadLine();
        }

    }
}
  




