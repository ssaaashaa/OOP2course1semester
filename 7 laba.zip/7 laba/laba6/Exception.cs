﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba6
{
    public class InventoryException:Exception
    {
        public string ErrorClass { get; }
        public InventoryException(string message):base(message)
        {
            
        }

    }
    public class BarsException : InventoryException
    {
        public BarsException(string message):base(message)
        {

        }

    }
    public class CostException : InventoryException
    {
        public int Cost { get; }
        public CostException(string message, int cost):base(message)
        {
            Cost = cost;
        }
    }

}
