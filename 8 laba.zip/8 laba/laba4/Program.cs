﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba8
{
    
    public class Bench  //скамейка
    {
        public string Name { get; set; }
        public string Material { get; set; }
        private int cost { get; set; }
        public int Cost
        {
            get { return cost; }
            set
            {
                if (value < 0)
                {
                    throw new CostException("Цена не может быть отрицательной.", cost);   //ИСКЛЮЧЕНИЕ

                }
                cost = value;
            }
        }

        public Bench()
        {
            Name = "Bench";
            Material = "Tree";
            Cost = 1000;
        }

        public Bench(string name, string material, int cost)
        {
            Name = name;
            Material = material;
            Cost = cost;
        }

        public override string ToString()
        {
            return ($"Name: {Name} \nMaterial: {Material} \nCost: {Cost}");
        }


    }
    public class MyList<T> : IGenericInterface<T> where T:new() 
    {
        public List<T> list;
        public MyList()
        {
            this.list = new List<T>();
        }

        public void AddElem(T element) //метод добавления элемента в список
        {
            list.Add(element);
            
        }

        public int Count() //метод возвращает количество элементов списка
        {
            return list.Count();
        }

        public T Element(int i) //метод возвращает элемент списка
        {
            return list[i];
        }
        public void Delete(T element)
        {
            list.Remove(element);
            
        }
        public void Info()
        {

            foreach(T i in list)
            {
                Console.WriteLine(i);
            }

        }
        public static MyList<T> operator !(MyList<T> list1) //перегрузка операторов-инверсия элементов
        {
            list1.list.Reverse();
            return list1;
        }


        public void Deletee(int element) //метод удаления элемента из списка
        {
            list.RemoveAt(element);
        }

        public static MyList<T> operator +(MyList<T> list1, MyList<T> list2) //перегрузка операторов-объединенеие двух списков
        {
            
            MyList<T> UnitedList = new MyList<T>();
            for (int i = 0; i < list1.Count(); i++)
            {
                T element = list1.Element(i);
                UnitedList.AddElem(element);
            }
            for (int i = 0; i < list2.Count(); i++)
            {
                T element = list2.Element(i);
                UnitedList.AddElem(element);
            }
            for (int i=0; i < UnitedList.Count();i++)
            {
                for (int j = i+1; j < UnitedList.Count(); j++)
                {
                    T element1 = UnitedList.Element(i);
                    T element2 = UnitedList.Element(j);
                    if (element1.Equals(element2))
                    {
                        
                        UnitedList.Deletee(j);
;                   }

                }
            }
            return UnitedList;

            
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }


        public static bool operator ==(MyList<T> list1, MyList<T> list2) //перегрузка операторов-сравнение двух списков
        {
            int count = 0;
            if (list1.Count() != list2.Count()) return false;
            else
            {
                for (int i = 0; i < list1.Count(); i++)
                {
                    T element1 = list1.Element(i);
                    T element2 = list2.Element(i);
                    if (element1.Equals(element2)) count += 1;
                }
                if (count == list1.Count()) return true;
                else return false;
            }
        }
        public static bool operator !=(MyList<T> list1, MyList<T> list2) 
        {
            int count = 0;
            if (list1.Count() != list2.Count()) return true;
            else
            {
                for (int i = 0; i < list1.Count(); i++)
                {
                    T element1 = list1.Element(i);
                    T element2 = list2.Element(i);
                    if (element1.Equals(element2)) count += 1;
                }
                if (count == list1.Count()) return false;
                else return true;
            }
        }



        public static MyList<T> operator <(MyList<T> list1, MyList<T> list2) //перегрузка операторов-добавление одного списка к другому
        {
            for (int i = 0; i < list2.Count(); i++)
            {
                T element = list2.Element(i);
                list1.AddElem(element);
            }
            return list1;
        }
        public static MyList<T> operator >(MyList<T> list1, MyList<T> list2)
        {
            for (int i = 0; i < list1.Count(); i++)
            {
                T element = list1.Element(i);
                list2.AddElem(element);
            }
            return list2;
        }
        
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            
            MyList<int> List1 = new MyList<int>();
            MyList<double> List2 = new MyList<double>();
            MyList<int> List3 = new MyList<int>();

            Console.WriteLine("Первый список <int>: ");
            List1.AddElem(1);
            List1.AddElem(2);
            List1.AddElem(3);
            List1.AddElem(4);
            List1.AddElem(5);
            List1.Info();
            List1.Delete(4);
            
            Console.WriteLine("Первый список <int> после удаления 4-ого элемента: ");
            List1.Info();
            Console.WriteLine();

            Console.WriteLine("Второй список <double>: ");
            List2.AddElem(1.2);
            List2.AddElem(5.8);
            List2.AddElem(9.25);
            List2.AddElem(4.16);
            List2.Info();
            Console.WriteLine();

            Console.WriteLine("Третий список <int>: ");
            List3.AddElem(2);
            List3.AddElem(4);
            List3.AddElem(5);
            List3.AddElem(6);
            List3.AddElem(2);
            List3.Info();
            Console.WriteLine();
            Console.WriteLine("Инверсия элементов 1-ого списка(!): ");
            MyList<int> List = !List1;
            List.Info();
            MyList<int> list = !List1;
            Console.WriteLine();
            Console.WriteLine("Объединение двух списков(+): ");
            MyList<int> UnitedList = List1 + List3;
            UnitedList.Info();
            Console.WriteLine();
            if (List1 == List3) Console.WriteLine("Равенство списков(==): списки равны.");
            else Console.WriteLine("Равенство списков(==): списки не равны.");
            Console.WriteLine();
            Console.WriteLine("Добавление одного списка к другому(<): ");
            List3 = List1 < List3;
            List3.Info();
            Console.WriteLine();
            Console.WriteLine();
            MyList<Bench> list4 = new MyList<Bench>();
            try
            {
                Bench bench0 = new Bench("bench", "дерево", -500);
            }
            catch(CostException ex)
            {
                Console.WriteLine(ex.Message+"\n"+ex.StackTrace);
            }
            finally
            {
                Console.WriteLine("\nFinally!\n");
;           }
            Bench bench1 = new Bench("bench", "дерево", 1500);
            Bench bench2 = new Bench("bench", "дерево", 1200);
            list4.AddElem(bench1);
            list4.AddElem(bench2);
            list4.Info();
            


        }
    }

}
