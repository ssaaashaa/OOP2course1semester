﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba8
{
    public interface IGenericInterface<T> where T:new()
    {
        void AddElem(T element);
        void Delete(T element);
        void Info();

    }
    public class CostException : Exception
    {
        public int Cost { get; }
        public CostException(string message, int cost) : base(message)
        {
            Cost = cost;
        }
    }
}
