﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba6
{
    // Инвентарь, Скамейка, Брусья, Мяч, Маты, Баскетбольный мяч, Теннис.
    //добавлены Теннисный мяч, Теннисная ракетка и Теннисный корт

    
    interface Ifor_methods
    {
        void Method();
    }

    interface IActions_for_inventary
    {
        void Take();
        void Put();
    }

    interface IFor_tennis_ball
    {
        void for_tennis_ball();
    }


    public abstract class Inventory
    {
        public string Name { get; set; }
        public int Cost { get; set; }
        public virtual void Item()
        {
            Console.WriteLine("Inventory.");
        }
        public abstract void Method();
    }

    public class Bench : Inventory, Ifor_methods  //скамейка
    {

        public string Material { get; set; }
        public override void Item()
        {
            Console.WriteLine("This inventory is a bench.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-скамейка (абстрактный класс).");
        }

        void Ifor_methods.Method()
        {
            Console.WriteLine("Этот инвентарь-скамейка (интерфейс).");
        }

        public Bench(string name, string material, int cost)
        {
            Cost = cost;
            Name = name;
            Material = material;
        }

        public override string ToString()
        {
            return ($"Name: {Name} \nMaterial: {Material} \nCost: {Cost} BYN");
        }
        public override int GetHashCode()
        {
            Console.WriteLine(Name.GetHashCode());
            return Name.GetHashCode();
        }
        public override bool Equals(object obj)
        {
            if (obj.GetType() != this.GetType()) return false;
            Bench bench = (Bench)obj;
            return (Material == bench.Material);
        }

    }

    public class Bars : Inventory, IActions_for_inventary  //брусья
    {
        public int Height { get; set; }
        public override void Item()
        {
            Console.WriteLine("This inventory is a bar.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-брусья.");
        }
        public Bars(string name, int height, int cost)
        {
            Cost = cost;
            Name = name;
            Height = height;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nHeight: {Height} cm \nCost: {Cost} BYN");
        }
        void IActions_for_inventary.Take()
        {
            Console.WriteLine("Вы выбрали брусья для занятий спортом.");
        }

        void IActions_for_inventary.Put()
        {
            Console.WriteLine("Вы закончили занятия спортом на брусьях.");
        }
    }

   public class Mats : Inventory
    {
        public int Width { get; set; }
        public override void Item()
        {
            Console.WriteLine("This inventory is a mat.");
        }
        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-мат.");
        }
        
        public Mats(string name, int width, int cost)
        {
            Cost = cost;
            Name = name;
            Width = width;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nWidth: {Width} cm \nCost: {Cost} BYN");

        }
    }

    public partial class Balls : Inventory
    {


        //5 laba
        public string Color { get; set; }

        public override void Item()
        {
            Console.WriteLine("This inventory is a ball.");
        }
        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-мяч.");
        }


    }

    public class Basketball_ball : Balls
    {
        //6 laba
        public enum TypeOfBasketballBall     //ПЕРЕЧИСЛЕНИЯ
        {
            ForTheHall = 1,
            ForTheStreet,
            Universal

        }

        public TypeOfBasketballBall Type { get; set; }

        //5 laba
        public override void Item()
        {
            Console.WriteLine("This inventory is a basketball ball.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-баскетбольный мяч.");
        }
        public Basketball_ball(string name, string color, int cost) : base(name)
        {
            Cost = cost;
            Type = TypeOfBasketballBall.Universal;
            Color = color;
        }
        public override string ToString()
        {
            return ($"Name: {Name} \nColor: {Color}\nType: {Type} \nCost: {Cost} BYN");
        }

    }

    public sealed class Tennis_ball : Balls, IFor_tennis_ball
    {
        public override void Item()
        {
            Console.WriteLine("This inventory is a tennis ball.");
        }

        public override void Method()
        {
            Console.WriteLine("Этот инвентарь-теннисный мяч.");
        }
        public Tennis_ball(string name, string color, int cost) : base(name)
        {
            Cost = cost;
            Color = color;
        }
        public override string ToString()
        {
            return ($"Name: {Name}\nColor: {Color} \nCost: {Cost} BYN");
        }
        void IFor_tennis_ball.for_tennis_ball()
        {
            Console.WriteLine($"Вы играете в теннис.");
        }
    }

    class Gym
    {
        public List<Inventory> shells { get; set; }
        public int Sum;
        public int FixedCount;
        public int Count = 0;
        public Gym(int sum, int fixedCount)
        {
            shells = new List<Inventory>();
            FixedCount = fixedCount;
            Sum = sum;
            Console.WriteLine($"Фиксированное количество: {FixedCount} ");
            Console.WriteLine($"Выделенная сумма денег: {sum} BYN");

        }
        public void Add(Inventory item) //ДОБАВЛЕНИЕ СНАРЯДОВ В ЗАВИСИМОСТИ ОТ ФИКС.КОЛ-ВА И ВЫДЕЛ.СУММЫ
        {

            if (Sum > item.Cost && Count < FixedCount)
            {
                shells.Add(item);
                Sum -= item.Cost;
                Count = shells.Count;
            }
            else
            {
                Console.WriteLine("\nБыла допущена ошибка! Превышено фиксированное количество или выделенная сумма денег.");
                if (Sum < item.Cost)
                {
                    Console.WriteLine("Превышена СУММА.");
                    Console.WriteLine("Недобавленный инвентраь:\n" + item.ToString());
                }
                else
                {

                    Console.WriteLine("Превышено КОЛИЧЕСТВО.");
                    Console.WriteLine("Недобавленный инвентраь:\n" + item.ToString());
                }

            }

        }
        public void Delete(int element) 
        {
            shells.RemoveAt(element);
            Console.WriteLine($"\n\nЭлемент {element + 1} удален.");
        }


        public void Info()
        {
            Console.WriteLine("\n-------СПИСОК ЭЛЕМЕНТОВ------- ");
            foreach (Inventory item in shells)
            {
                Console.WriteLine(item + "\n");
            }
        }
    }



    class Controller
    {
        public List<Inventory> Sort(Gym gym)  //СОРТИРОВКА
        {
            List<Inventory> inventories = new List<Inventory>();
            foreach (Inventory item in gym.shells)
            {
                inventories.Add(item);
            }
            inventories.Sort((item1, item2) => item1.Cost.CompareTo(item2.Cost));
            return inventories;


        }
        public void Range(Gym gym, int min, int max)  //ЗАДАННЫЙ ДИАПАЗОН ЦЕН
        {
            List<Inventory> inventories = new List<Inventory>();
            Console.WriteLine($"\nИнвентарь, соответствующий диапозону цен от {min} BYN до {max} BYN: ");
            foreach (Inventory item in gym.shells)
            {
                if (item.Cost >= min && item.Cost <= max)
                {
                    inventories.Add(item);
                    Console.WriteLine(item+"\n");
                }
            }

        }


        public class Printer
        {
            public string IAmPrinting(Inventory someobj)
            {

                if (someobj is Bench)
                {
                    return someobj.ToString();
                }
                else if (someobj is Bars)
                {
                    return someobj.ToString();
                }

                else if (someobj is Mats)
                {
                    return someobj.ToString();
                }

                else if (someobj is Tennis_ball)
                {
                    return someobj.ToString();
                }
                else
                {
                    return String.Format("Ошибка!");
                }
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("-------ИЕРАРХИЯ НАСЛЕДОВАНИЯ ОТ ИНВЕНТАРЯ-------");
                Console.WriteLine();
                Console.WriteLine("----Скамейка----");
                Bench bench1 = new Bench("Скамейка №1", "дерево", 1200);
                Bench bench2 = new Bench("Скамейка №2", "дерево", 1000);
                Bench bench3 = new Bench("Скамейка №3", "сталь", 1600);
                Ifor_methods bench = bench1;
                bench1.Item();
                bench1.Method();
                bench.Method();
                Console.WriteLine(bench1.ToString());
                Console.WriteLine(bench1.Equals(bench2));
                Console.WriteLine(bench1.Equals(bench3));
                bench1.GetHashCode();
                Console.WriteLine("Оператор is для bench1 is Bench: " + (bench1 is Bench));
                Console.WriteLine();


                Console.WriteLine("----Брусья----");
                Bars bar = new Bars("Брусья", 140, 800);
                IActions_for_inventary bar1 = bar;
                bar.Item();
                bar.Method();
                Console.WriteLine(bar.ToString());
                bar1.Take();
                bar1.Put();
                Console.WriteLine();


                Console.WriteLine("----Маты----");
                Mats mat = new Mats("Мат", 10, 800);
                mat.Item();
                mat.Method();
                Console.WriteLine(mat.ToString());
                Console.WriteLine();

                Console.WriteLine("----Мячи---");
                Balls balls = new Balls("Мяч", 5);
                balls.Item();
                balls.Method();
                Console.WriteLine(balls.ToString());
                Console.WriteLine();

                Console.WriteLine("----Баскетбольный мяч---");
                Basketball_ball ball1 = new Basketball_ball("Баскетбольный мяч", "оранжевый", 35);
                ball1.Item();
                ball1.Method();
                Console.WriteLine(ball1.ToString());
                Console.WriteLine();


                Console.WriteLine("----Теннисный мяч---");
                Tennis_ball ball2 = new Tennis_ball("Теннисный мяч", "желтый", 15);
                IFor_tennis_ball ball3 = ball2;
                ball2.Item();
                ball2.Method();
                Console.WriteLine(ball2.ToString());
                ball3.for_tennis_ball();
                Console.WriteLine();
                ball1 = balls as Basketball_ball;
                if (ball1 == null)
                {
                    Console.WriteLine("Невозможно привести balls к типу Basketball_ball.");
                }
                else
                {
                    Console.WriteLine("Можно привести balls к типу Basketball_ball.");
                }

                balls = ball2 as Balls;
                if (balls == null)
                {
                    Console.WriteLine("Невозможно привести ball2 к типу Balls.");
                }
                else
                {
                    Console.WriteLine("Можно привести ball2 к типу Balls.");
                }
                Console.WriteLine();


                Console.WriteLine("----Массив---");
                Bench bench0 = new Bench("Скамейка", "дерево", 1000);
                Bars bar0 = new Bars("Брусья", 120, 1050);
                Mats mat0 = new Mats("Мат", 15, 150);
                Basketball_ball ball0 = new Basketball_ball("Баскетбольный мяч", "оранжевый", 350);
                var array = new Inventory[4];
                Printer printer = new Printer();
                array[0] = bench0;
                array[1] = bar0;
                array[2] = mat0;
                array[3] = ball0;
                foreach (var someobj in array)
                {
                    Console.WriteLine(printer.IAmPrinting(someobj));
                    Console.WriteLine();
                }

                /////////////////////////////////////////////////////
                Console.WriteLine("-------------6 LABA------------");
                Gym gym = new Gym(2000, 4);
                gym.Add(bench0);
                gym.Add(bar0);
                gym.Add(mat0);
                gym.Add(ball0);
                gym.Add(ball2);
                gym.Add(mat0);
                gym.Info();
                gym.Delete(1);
                gym.Info();

                Controller controller = new Controller();
                controller.Range(gym, 10, 500);
                Console.WriteLine();

                Gym gym0 = new Gym(10000, 10);
                gym0.Add(bench0);
                gym0.Add(bench1);
                gym0.Add(bench2);
                gym0.Add(bench3);
                gym0.Add(bar0);
                gym0.Add(bar);
                gym0.Add(mat);

                gym0.Info();

                
                List<Inventory> sort = controller.Sort(gym0);
                Console.WriteLine("ОТСОРТИРОВАННЫЙ СПИСОК: \n");
                foreach(Inventory item in sort)
                {
                    Console.WriteLine(item+"\n");
                }



            }
        }
    }
}


