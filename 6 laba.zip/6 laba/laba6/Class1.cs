﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba6
{
    public partial class Balls
    {
        //6 laba

        public struct StructBalls  //СТРУКТУРА
        {
            public int Count;
            public StructBalls(int count)
            {
                Count = count;
            }
            public void StructFun()
            {
                Console.WriteLine($"Всего мячей {Count}");
            }
        }
        StructBalls structBalls;
        public Balls(string name, int count)
        {

            Name = name;
            structBalls = new Balls.StructBalls(count);
        }
        public override string ToString()
        {
            return ($"Name: {Name}\nCount: {structBalls.Count} ");
        }
        public Balls(string Name)
        {
            this.Name = Name;
        }

    }
}
